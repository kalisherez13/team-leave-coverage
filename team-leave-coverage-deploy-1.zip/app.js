const STORAGE_KEY = 'team_leave_coverage_v2';
const DAYS_HE = ['א׳','ב׳','ג׳','ד׳','ה׳','ו׳','ש׳'];
const MONTHS_HE = ['ינואר','פברואר','מרץ','אפריל','מאי','יוני','יולי','אוגוסט','ספטמבר','אוקטובר','נובמבר','דצמבר'];

const initialState = {
  staff: [],
  leaves: [],
  coverages: [],
  settings: { coverageRequiredFromAbsentCount: 1 },
  pendingClinicSync: []
};

let state = loadState();
let currentView = 'week';
let anchorDate = startOfDay(new Date());
let editingLeaveId = null;
let editingCoverageId = null;

const content = document.getElementById('content');
const periodTitle = document.getElementById('periodTitle');
const coverageAlert = document.getElementById('coverageAlert');
const clinicSyncAlert = document.getElementById('clinicSyncAlert');
const dateNav = document.getElementById('dateNav');

function loadState(){
  try {
    const parsed = JSON.parse(localStorage.getItem(STORAGE_KEY));
    return parsed ? {...initialState, ...parsed, settings:{...initialState.settings, ...(parsed.settings||{})}} : structuredClone(initialState);
  } catch { return structuredClone(initialState); }
}
function saveState(){ localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); }
function uid(prefix='id'){ return `${prefix}_${Date.now()}_${Math.random().toString(36).slice(2,8)}`; }
function startOfDay(d){ const x=new Date(d); x.setHours(0,0,0,0); return x; }
function parseDate(s){ const [y,m,d]=s.split('-').map(Number); return new Date(y,m-1,d); }
function toISO(d){ const x=startOfDay(d); return `${x.getFullYear()}-${String(x.getMonth()+1).padStart(2,'0')}-${String(x.getDate()).padStart(2,'0')}`; }
function addDays(d,n){ const x=new Date(d); x.setDate(x.getDate()+n); return startOfDay(x); }
function dateRange(start,end){ const out=[]; for(let d=startOfDay(start); d<=startOfDay(end); d=addDays(d,1)) out.push(d); return out; }
function formatDate(d){ return new Intl.DateTimeFormat('he-IL',{day:'2-digit',month:'2-digit',year:'numeric'}).format(d); }
function formatShort(d){ return new Intl.DateTimeFormat('he-IL',{day:'numeric',month:'numeric'}).format(d); }
function daysBetweenInclusive(a,b){ return Math.round((startOfDay(b)-startOfDay(a))/86400000)+1; }
function startOfWeek(d){ const x=startOfDay(d); x.setDate(x.getDate()-x.getDay()); return x; }
function endOfWeek(d){ return addDays(startOfWeek(d),6); }
function startOfMonth(d){ return new Date(d.getFullYear(),d.getMonth(),1); }
function endOfMonth(d){ return new Date(d.getFullYear(),d.getMonth()+1,0); }
function clampDate(d,min,max){ return d<min?min:d>max?max:d; }
function staffName(id){ return state.staff.find(s=>s.id===id)?.name || 'לא ידוע'; }

function leavesOn(date){ const iso=toISO(date); return state.leaves.filter(l=>l.start<=iso && l.end>=iso); }
function coveragesOn(date){ const iso=toISO(date); return state.coverages.filter(c=>c.start<=iso && c.end>=iso); }
function absenceCount(date){ return leavesOn(date).length; }
function riskForDate(date){ const n=absenceCount(date); return n>=3?'red':n===2?'orange':n===1?'green':'none'; }
function coverageRequired(date){ return absenceCount(date) >= state.settings.coverageRequiredFromAbsentCount; }
function isCovered(date){ return coveragesOn(date).length>0; }
function isUnresolved(date){ return coverageRequired(date) && !isCovered(date); }

function allUnresolvedDates(){
  const set=new Set();
  state.leaves.forEach(l=>dateRange(parseDate(l.start),parseDate(l.end)).forEach(d=>{ if(isUnresolved(d)) set.add(toISO(d)); }));
  return [...set].sort();
}
function updateCoverageAlert(){
  const unresolved=allUnresolvedDates();
  if(!unresolved.length){ coverageAlert.classList.add('hidden'); coverageAlert.innerHTML=''; return; }
  const first=parseDate(unresolved[0]), last=parseDate(unresolved[unresolved.length-1]);
  coverageAlert.classList.remove('hidden');
  coverageAlert.innerHTML=`<span>יש ${unresolved.length} ${unresolved.length===1?'יום':'ימים'} עם חופשה ללא גיבוי. כל חופשה מחייבת גיבוי.</span><button id="resolveCoverageBtn" class="primary">הוספת גיבוי</button>`;
  document.getElementById('resolveCoverageBtn').onclick=()=>openCoverageForDates(first,last,true);
}
function renderClinicSyncAlert(){
  let pendingLeaves=state.pendingClinicSync.map(id=>state.leaves.find(l=>l.id===id)).filter(Boolean);
  if(pendingLeaves.length!==state.pendingClinicSync.length){ state.pendingClinicSync=pendingLeaves.map(l=>l.id); saveState(); }
  if(!pendingLeaves.length){ clinicSyncAlert.classList.add('hidden'); clinicSyncAlert.innerHTML=''; return; }
  pendingLeaves=pendingLeaves.slice().sort((a,b)=>a.start.localeCompare(b.start));
  let html=`<div class="sync-header">💡 יש ${pendingLeaves.length} ${pendingLeaves.length===1?'חופשה חדשה שטרם הוזנה':'חופשות חדשות שטרם הוזנו'} למערכת הקליניקה — יש לסמן ✔ אחרי ההזנה:</div><div class="sync-list">`;
  pendingLeaves.forEach(l=>{
    const range = l.start===l.end ? formatDate(parseDate(l.start)) : `${formatDate(parseDate(l.start))}–${formatDate(parseDate(l.end))}`;
    html+=`<div class="sync-item"><span>${escapeHtml(staffName(l.staffId))} · ${range}</span><button type="button" class="sync-done-btn" data-mark-synced="${l.id}">✔ הוזן במערכת</button></div>`;
  });
  html+='</div>';
  clinicSyncAlert.classList.remove('hidden'); clinicSyncAlert.innerHTML=html;
  clinicSyncAlert.querySelectorAll('[data-mark-synced]').forEach(btn=>btn.onclick=()=>{
    state.pendingClinicSync=state.pendingClinicSync.filter(id=>id!==btn.dataset.markSynced);
    saveState(); renderClinicSyncAlert();
  });
}

function render(){
  updateCoverageAlert();
  renderClinicSyncAlert();
  document.querySelectorAll('[data-view]').forEach(b=>b.classList.toggle('active', b.dataset.view===currentView));
  dateNav.classList.toggle('hidden', currentView==='reports');
  if(currentView==='week') renderWeek();
  if(currentView==='month') renderMonth();
  if(currentView==='year') renderYear();
  if(currentView==='reports') renderReports();
}

function renderWeek(){
  const start=startOfWeek(anchorDate), end=endOfWeek(anchorDate);
  periodTitle.textContent=`${formatShort(start)} – ${formatDate(end)}`;
  const days=dateRange(start,end);
  let html='<div class="week-head">';
  days.forEach(d=>html+=`<div class="day-head ${toISO(d)===toISO(new Date())?'today':''}"><div class="dow">${DAYS_HE[d.getDay()]}</div><div class="date">${d.getDate()}</div><div class="dow">${MONTHS_HE[d.getMonth()]}</div></div>`);
  html+='</div>';
  html+='<div class="section-title"><span>חופשות</span><small>צבע הפס נקבע לפי מספר הנעדרים בכל יום</small></div>';
  const weekLeaves=state.leaves.filter(l=>parseDate(l.end)>=start && parseDate(l.start)<=end);
  if(!weekLeaves.length) html+='<div class="empty">אין חופשות בשבוע זה.</div>';
  else weekLeaves.sort((a,b)=>a.start.localeCompare(b.start)).forEach(l=>{ html+=leaveWeekRow(l,start,end); });
  html+='<div class="section-title"><span>גיבויים</span><small>אפור = גיבוי שהוגדר</small></div>';
  const weekCoverage=state.coverages.filter(c=>parseDate(c.end)>=start && parseDate(c.start)<=end);
  if(!weekCoverage.length) html+='<div class="empty">לא הוגדרו גיבויים בשבוע זה.</div>';
  else weekCoverage.sort((a,b)=>a.start.localeCompare(b.start)).forEach(c=>{ html+=coverageWeekRow(c,start,end); });
  content.innerHTML=html;
}

function leaveWeekRow(l,weekStart,weekEnd){
  const s=clampDate(parseDate(l.start),weekStart,weekEnd), e=clampDate(parseDate(l.end),weekStart,weekEnd);
  const runs=[]; let runStart=s, prevRisk=riskForDate(s), prevMissing=isUnresolved(s);
  for(let d=addDays(s,1); d<=e; d=addDays(d,1)){
    const r=riskForDate(d), m=isUnresolved(d);
    if(r!==prevRisk || m!==prevMissing){ runs.push({start:runStart,end:addDays(d,-1),risk:prevRisk,missing:prevMissing}); runStart=d; prevRisk=r; prevMissing=m; }
  }
  runs.push({start:runStart,end:e,risk:prevRisk,missing:prevMissing});
  let html='<div class="event-row">';
  runs.forEach((run,i)=>{
    const colStart=Math.round((run.start-weekStart)/86400000)+1;
    const span=daysBetweenInclusive(run.start,run.end);
    html+=`<div class="event-segment leave-${run.risk} ${run.missing?'unresolved-segment':''}" data-leave-id="${l.id}" style="grid-column:${colStart}/span ${span}" title="${escapeHtml(staffName(l.staffId))} | ${formatDate(run.start)}–${formatDate(run.end)}${run.missing?' | ללא גיבוי':''} | לחיצה לעריכה">${i===0?escapeHtml(staffName(l.staffId)):''}${run.missing?' · דורש גיבוי':''}</div>`;
  });
  html+='</div>'; return html;
}
function coverageWeekRow(c,weekStart,weekEnd){
  const s=clampDate(parseDate(c.start),weekStart,weekEnd), e=clampDate(parseDate(c.end),weekStart,weekEnd);
  const colStart=Math.round((s-weekStart)/86400000)+1, span=daysBetweenInclusive(s,e);
  return `<div class="event-row"><div class="event-segment coverage-segment" data-coverage-id="${c.id}" style="grid-column:${colStart}/span ${span}" title="${escapeHtml(staffName(c.staffId))} ${c.from}-${c.to} | לחיצה לעריכה">${escapeHtml(staffName(c.staffId))} · ${c.from}–${c.to}</div></div>`;
}

function renderMonth(){
  const first=startOfMonth(anchorDate), last=endOfMonth(anchorDate);
  periodTitle.textContent=`${MONTHS_HE[first.getMonth()]} ${first.getFullYear()}`;
  const gridStart=startOfWeek(first), gridEnd=endOfWeek(last);
  let html='<div class="month-grid">';
  DAYS_HE.forEach(d=>html+=`<div class="month-weekday">${d}</div>`);
  dateRange(gridStart,gridEnd).forEach(d=>{
    const leaves=leavesOn(d), cov=coveragesOn(d), risk=riskForDate(d), outside=d.getMonth()!==first.getMonth();
    html+=`<div class="month-day ${outside?'outside':''} ${toISO(d)===toISO(new Date())?'today':''}" data-day="${toISO(d)}"><div class="month-day-num">${d.getDate()}</div>`;
    leaves.forEach(l=>html+=`<span class="mini-chip leave-${risk}" data-leave-id="${l.id}">${escapeHtml(staffName(l.staffId))}</span>`);
    cov.forEach(c=>html+=`<span class="mini-chip coverage-chip" data-coverage-id="${c.id}">גיבוי: ${escapeHtml(staffName(c.staffId))} ${c.from}–${c.to}</span>`);
    if(isUnresolved(d)) html+='<span class="missing-badge" data-add-coverage-day="'+toISO(d)+'">דורש גיבוי · הוספת גיבוי</span>';
    html+='<button type="button" class="add-coverage-day-btn" data-add-coverage-day="'+toISO(d)+'" title="הוספת גיבוי ליום זה">+ גיבוי</button>';
    html+='</div>';
  });
  html+='</div>'; content.innerHTML=html;
}

function renderYear(){
  const year=anchorDate.getFullYear(); periodTitle.textContent=String(year);
  let html='<div class="year-grid">';
  for(let m=0;m<12;m++){
    const first=new Date(year,m,1), last=endOfMonth(first), gridStart=startOfWeek(first), gridEnd=endOfWeek(last);
    html+=`<div class="mini-month"><h3>${MONTHS_HE[m]}</h3><div class="mini-month-grid">`;
    DAYS_HE.forEach(d=>html+=`<div class="month-weekday">${d}</div>`);
    dateRange(gridStart,gridEnd).forEach(d=>{
      const outside=d.getMonth()!==m; const risk=riskForDate(d); const cls=outside?'':risk;
      html+=`<div class="mini-day ${cls} ${isUnresolved(d)?'missing':''} ${isCovered(d)&&coverageRequired(d)?'has-coverage':''}" style="opacity:${outside?.28:1}" title="${formatDate(d)} | נעדרים: ${absenceCount(d)} | גיבויים: ${coveragesOn(d).length}">${outside?'':d.getDate()}</div>`;
    });
    html+='</div></div>';
  }
  html+='</div>'; content.innerHTML=html;
}

function renderReports(){
  const rows=state.staff.map(s=>{
    const leaves=state.leaves.filter(l=>l.staffId===s.id);
    const coverages=state.coverages.filter(c=>c.staffId===s.id);
    const leaveDays=leaves.reduce((sum,l)=>sum+daysBetweenInclusive(parseDate(l.start),parseDate(l.end)),0);
    const coverageHours=coverages.reduce((sum,c)=>sum+hoursBetween(c.from,c.to)*daysBetweenInclusive(parseDate(c.start),parseDate(c.end)),0);
    return {name:s.name, leaveCount:leaves.length, leaveDays, coverageCount:coverages.length, coverageHours};
  });
  const totals=rows.reduce((a,r)=>({leaveCount:a.leaveCount+r.leaveCount,leaveDays:a.leaveDays+r.leaveDays,coverageCount:a.coverageCount+r.coverageCount,coverageHours:a.coverageHours+r.coverageHours}),{leaveCount:0,leaveDays:0,coverageCount:0,coverageHours:0});
  let html=`<div class="report-summary"><div class="metric"><b>${totals.leaveCount}</b><span>אירועי חופשה</span></div><div class="metric"><b>${totals.leaveDays}</b><span>ימי חופשה</span></div><div class="metric"><b>${totals.coverageCount}</b><span>אירועי גיבוי</span></div><div class="metric"><b>${totals.coverageHours.toFixed(1)}</b><span>שעות גיבוי</span></div></div>`;
  html+='<div class="report-actions"><button id="exportCsvBtn">ייצוא CSV</button></div>';
  html+='<table><thead><tr><th>עובד/ת</th><th>מספר חופשות</th><th>ימי חופשה</th><th>מספר גיבויים</th><th>שעות גיבוי</th></tr></thead><tbody>';
  rows.forEach(r=>html+=`<tr><td>${escapeHtml(r.name)}</td><td>${r.leaveCount}</td><td>${r.leaveDays}</td><td>${r.coverageCount}</td><td>${r.coverageHours.toFixed(1)}</td></tr>`);
  html+='</tbody></table>'; content.innerHTML=html;
  document.getElementById('exportCsvBtn').onclick=()=>exportCSV(rows);
}
function hoursBetween(a,b){ const [ah,am]=a.split(':').map(Number), [bh,bm]=b.split(':').map(Number); let mins=(bh*60+bm)-(ah*60+am); if(mins<0) mins+=24*60; return mins/60; }
function exportCSV(rows){
  const lines=[['עובד/ת','מספר חופשות','ימי חופשה','מספר גיבויים','שעות גיבוי'],...rows.map(r=>[r.name,r.leaveCount,r.leaveDays,r.coverageCount,r.coverageHours.toFixed(1)])];
  const csv='\uFEFF'+lines.map(row=>row.map(v=>`"${String(v).replaceAll('"','""')}"`).join(',')).join('\n');
  const blob=new Blob([csv],{type:'text/csv;charset=utf-8'}), url=URL.createObjectURL(blob), a=document.createElement('a'); a.href=url; a.download='team-leave-coverage-report.csv'; a.click(); URL.revokeObjectURL(url);
}
function escapeHtml(s){ return String(s).replace(/[&<>"]/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[ch])); }

function refreshStaffSelects(){
  ['leaveStaff','coverageStaff'].forEach(id=>{
    const el=document.getElementById(id); const current=el.value; el.innerHTML='<option value="">בחירה</option>'+state.staff.map(s=>`<option value="${s.id}">${escapeHtml(s.name)}</option>`).join(''); if([...el.options].some(o=>o.value===current)) el.value=current;
  });
}
function openLeaveDialog(leave=null){
  if(!state.staff.length){ openStaffDialog(); return; }
  refreshStaffSelects();
  editingLeaveId = leave ? leave.id : null;
  document.getElementById('leaveDialogTitle').textContent = leave ? 'עריכת חופשה' : 'הוספת חופשה';
  document.getElementById('deleteLeaveBtn').classList.toggle('hidden', !leave);
  document.getElementById('leaveStaff').value = leave ? leave.staffId : '';
  document.getElementById('leaveStart').value = leave ? leave.start : toISO(anchorDate);
  document.getElementById('leaveEnd').value = leave ? leave.end : toISO(anchorDate);
  document.getElementById('leaveNote').value = leave ? (leave.note||'') : '';
  document.getElementById('leaveDialog').showModal();
}
function openCoverageForDates(start,end,fromAlert=false){
  if(!state.staff.length){ openStaffDialog(); return; }
  refreshStaffSelects();
  editingCoverageId = null;
  document.getElementById('coverageDialogTitle').textContent='הוספת גיבוי';
  document.getElementById('deleteCoverageBtn').classList.add('hidden');
  document.getElementById('coverageStaff').value='';
  document.getElementById('coverageStart').value=toISO(start); document.getElementById('coverageEnd').value=toISO(end); document.getElementById('coverageFrom').value='08:00'; document.getElementById('coverageTo').value='16:00';
  document.getElementById('coverageNote').value='';
  const reason=document.getElementById('coverageReason');
  if(fromAlert){ reason.classList.remove('hidden'); reason.textContent='קיימת חופשה ללא גיבוי. יש להגדיר לפחות מגבה אחד לכל יום שבו יש עובד בחופש.'; } else reason.classList.add('hidden');
  document.getElementById('coverageDialog').showModal();
}
function openCoverageDialog(){ openCoverageForDates(anchorDate,anchorDate,false); }
function openCoverageEditDialog(coverage){
  if(!state.staff.length){ openStaffDialog(); return; }
  refreshStaffSelects();
  editingCoverageId = coverage.id;
  document.getElementById('coverageDialogTitle').textContent='עריכת גיבוי';
  document.getElementById('deleteCoverageBtn').classList.remove('hidden');
  document.getElementById('coverageStaff').value=coverage.staffId;
  document.getElementById('coverageStart').value=coverage.start; document.getElementById('coverageEnd').value=coverage.end;
  document.getElementById('coverageFrom').value=coverage.from; document.getElementById('coverageTo').value=coverage.to;
  document.getElementById('coverageNote').value=coverage.note||'';
  document.getElementById('coverageReason').classList.add('hidden');
  document.getElementById('coverageDialog').showModal();
}
function openStaffDialog(){ renderStaffList(); document.getElementById('staffDialog').showModal(); }
function renderStaffList(){
  const box=document.getElementById('staffList');
  box.innerHTML=state.staff.length?state.staff.map(s=>`<div class="staff-item"><span>${escapeHtml(s.name)}</span><button class="danger" data-remove-staff="${s.id}">הסרה</button></div>`).join(''):'<div class="empty">עדיין לא הוזנו אנשי צוות.</div>';
  box.querySelectorAll('[data-remove-staff]').forEach(btn=>btn.onclick=()=>removeStaff(btn.dataset.removeStaff));
}
function removeStaff(id){
  if(state.leaves.some(l=>l.staffId===id)||state.coverages.some(c=>c.staffId===id)){ alert('לא ניתן להסיר עובד שיש לו חופשות או גיבויים רשומים.'); return; }
  state.staff=state.staff.filter(s=>s.id!==id); saveState(); renderStaffList(); refreshStaffSelects(); render();
}

// Events
[...document.querySelectorAll('[data-view]')].forEach(btn=>btn.addEventListener('click',()=>{ currentView=btn.dataset.view; render(); }));
document.getElementById('prevPeriodBtn').onclick=()=>{ if(currentView==='week') anchorDate=addDays(anchorDate,-7); if(currentView==='month') anchorDate=new Date(anchorDate.getFullYear(),anchorDate.getMonth()-1,1); if(currentView==='year') anchorDate=new Date(anchorDate.getFullYear()-1,0,1); render(); };
document.getElementById('nextPeriodBtn').onclick=()=>{ if(currentView==='week') anchorDate=addDays(anchorDate,7); if(currentView==='month') anchorDate=new Date(anchorDate.getFullYear(),anchorDate.getMonth()+1,1); if(currentView==='year') anchorDate=new Date(anchorDate.getFullYear()+1,0,1); render(); };
document.getElementById('todayBtn').onclick=()=>{ anchorDate=startOfDay(new Date()); render(); };
document.getElementById('addLeaveBtn').onclick=()=>openLeaveDialog();
document.getElementById('addCoverageBtn').onclick=()=>openCoverageDialog();
document.getElementById('manageStaffBtn').onclick=openStaffDialog;
document.querySelectorAll('[data-close]').forEach(btn=>btn.onclick=()=>document.getElementById(btn.dataset.close).close());

content.addEventListener('click', e=>{
  const leaveEl = e.target.closest('[data-leave-id]');
  if(leaveEl){ const leave=state.leaves.find(l=>l.id===leaveEl.dataset.leaveId); if(leave) openLeaveDialog(leave); return; }
  const covEl = e.target.closest('[data-coverage-id]');
  if(covEl){ const cov=state.coverages.find(c=>c.id===covEl.dataset.coverageId); if(cov) openCoverageEditDialog(cov); return; }
  const addCovEl = e.target.closest('[data-add-coverage-day]');
  if(addCovEl){ const day=parseDate(addCovEl.dataset.addCoverageDay); openCoverageForDates(day,day,false); return; }
});

document.getElementById('deleteLeaveBtn').onclick=()=>{
  if(!editingLeaveId) return;
  if(!confirm('למחוק את החופשה? הפעולה אינה הפיכה.')) return;
  state.leaves=state.leaves.filter(l=>l.id!==editingLeaveId);
  state.pendingClinicSync=state.pendingClinicSync.filter(id=>id!==editingLeaveId);
  saveState();
  document.getElementById('leaveDialog').close(); editingLeaveId=null; render();
};
document.getElementById('deleteCoverageBtn').onclick=()=>{
  if(!editingCoverageId) return;
  if(!confirm('למחוק את הגיבוי? הפעולה אינה הפיכה.')) return;
  state.coverages=state.coverages.filter(c=>c.id!==editingCoverageId); saveState();
  document.getElementById('coverageDialog').close(); editingCoverageId=null; render();
};

document.getElementById('staffForm').addEventListener('submit',e=>{
  e.preventDefault(); const input=document.getElementById('staffName'), name=input.value.trim(); if(!name) return; state.staff.push({id:uid('staff'),name}); input.value=''; saveState(); renderStaffList(); refreshStaffSelects(); render();
});

document.getElementById('leaveForm').addEventListener('submit',e=>{
  e.preventDefault();
  const staffId=document.getElementById('leaveStaff').value, start=document.getElementById('leaveStart').value, end=document.getElementById('leaveEnd').value, note=document.getElementById('leaveNote').value.trim();
  if(!staffId||!start||!end) return; if(end<start){ alert('תאריך הסיום חייב להיות זהה או מאוחר מתאריך ההתחלה.'); return; }
  if(editingLeaveId){
    const idx=state.leaves.findIndex(l=>l.id===editingLeaveId);
    if(idx>-1) state.leaves[idx]={...state.leaves[idx],staffId,start,end,note};
  } else {
    const newId=uid('leave');
    state.leaves.push({id:newId,staffId,start,end,note});
    state.pendingClinicSync.push(newId);
  }
  saveState(); document.getElementById('leaveDialog').close(); document.getElementById('leaveForm').reset(); editingLeaveId=null; render();
});

document.getElementById('coverageForm').addEventListener('submit',e=>{
  e.preventDefault();
  const staffId=document.getElementById('coverageStaff').value, start=document.getElementById('coverageStart').value, end=document.getElementById('coverageEnd').value, from=document.getElementById('coverageFrom').value, to=document.getElementById('coverageTo').value, note=document.getElementById('coverageNote').value.trim();
  if(!staffId||!start||!end||!from||!to) return; if(end<start){ alert('תאריך הסיום חייב להיות זהה או מאוחר מתאריך ההתחלה.'); return; }
  if(editingCoverageId){
    const idx=state.coverages.findIndex(c=>c.id===editingCoverageId);
    if(idx>-1) state.coverages[idx]={...state.coverages[idx],staffId,start,end,from,to,note};
  } else {
    state.coverages.push({id:uid('coverage'),staffId,start,end,from,to,note});
  }
  saveState(); document.getElementById('coverageDialog').close(); document.getElementById('coverageForm').reset(); editingCoverageId=null; render();
});

refreshStaffSelects();
render();
